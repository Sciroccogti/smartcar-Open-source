/*
 *	VERSION:	SCS-1.0.1
 *	DATE:		2013.Sep.1
 *	AUTHOR:		Yu Kunlin
 */

#ifndef _KEY_H_
#define _KEY_H_

#define ESCAPE		27
#define PAGE_UP		73
#define PAGE_DOWN	81

#endif
