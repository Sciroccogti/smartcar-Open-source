sim_car
=======

一个智能车循迹仿真软件，有自带解释器。

使用时，用类 c 语法将算法写入在文本中，运行时载入。

效果图
![car](https://raw.githubusercontent.com/lyyyuna/sim_car/master/img/car.png)