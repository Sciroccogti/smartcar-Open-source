

#ifndef  __MYKey_H__
#define  __MYKey_H__

#include "MK60DZ10.h"
#include "LDPY_GPIO.h"
#include "LDPY_SysTick.h"
#include "LDPY_EXTI.h"

void myKey_Init(void);
void myKey_StartEndLineInit(void);


#endif 

/*-------------------------end of myKey.h-------------------------*/
